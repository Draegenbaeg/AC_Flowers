class Flower:
    def __init__(self, breed, color, is_perfect):
        self.breed = breed
        self.color = color
        self.is_perfect = is_perfect